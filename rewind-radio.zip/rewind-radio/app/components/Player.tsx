"use client";

import { useCallback, useEffect, useRef, useState, type ChangeEvent } from "react";
import { tracks } from "@/app/lib/tracks";

function formatTime(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function PrevIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4">
      <path d="M7 6a1 1 0 0 1 1 1v10a1 1 0 1 1-2 0V7a1 1 0 0 1 1-1zm12.4.2a1 1 0 0 1 .6.9v9.8a1 1 0 0 1-1.53.85l-8-4.9a1 1 0 0 1 0-1.7l8-4.9a1 1 0 0 1 .93-.05z" />
    </svg>
  );
}

function NextIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4">
      <path d="M17 6a1 1 0 0 1 1 1v10a1 1 0 1 1-2 0V7a1 1 0 0 1 1-1zM4.6 6.2a1 1 0 0 1 .93.05l8 4.9a1 1 0 0 1 0 1.7l-8 4.9A1 1 0 0 1 4 16.9V7.1a1 1 0 0 1 .6-.9z" />
    </svg>
  );
}

function PlayIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4 translate-x-[1px]">
      <path d="M7 5.5a1 1 0 0 1 1.53-.85l10 6.5a1 1 0 0 1 0 1.7l-10 6.5A1 1 0 0 1 7 18.5v-13z" />
    </svg>
  );
}

function PauseIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4">
      <path d="M7 5a1.5 1.5 0 0 1 1.5 1.5v11a1.5 1.5 0 0 1-3 0v-11A1.5 1.5 0 0 1 7 5zm10 0a1.5 1.5 0 0 1 1.5 1.5v11a1.5 1.5 0 0 1-3 0v-11A1.5 1.5 0 0 1 17 5z" />
    </svg>
  );
}

export default function Player() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [index, setIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [coverFailed, setCoverFailed] = useState(false);

  const track = tracks[index];

  useEffect(() => {
    setCoverFailed(false);
    setCurrentTime(0);
    setDuration(0);
  }, [index]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.play().catch(() => setIsPlaying(false));
    } else {
      audio.pause();
    }
  }, [isPlaying, index]);

  const togglePlay = useCallback(() => setIsPlaying((p) => !p), []);

  const goNext = useCallback(() => {
    setIndex((i) => (i + 1) % tracks.length);
    setIsPlaying(true);
  }, []);

  const goPrev = useCallback(() => {
    setIndex((i) => (i - 1 + tracks.length) % tracks.length);
    setIsPlaying(true);
  }, []);

  const onSeek = useCallback((e: ChangeEvent<HTMLInputElement>) => {
    const audio = audioRef.current;
    const value = Number(e.target.value);
    setCurrentTime(value);
    if (audio) audio.currentTime = value;
  }, []);

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="safe-inset w-full max-w-xl px-4 pb-[var(--edge)]">
      {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
      <audio
        ref={audioRef}
        src={track.src}
        onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
        onEnded={goNext}
        onError={() => setIsPlaying(false)}
        preload="metadata"
      />

      {/* ---------- desktop: one horizontal pill ---------- */}
      <div className="glass hidden w-full items-center gap-4 rounded-full px-3 py-3 md:flex">
        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-full ring-1 ring-white/10">
          <div
            className="h-full w-full animate-spin-slow"
            style={{ animationPlayState: isPlaying ? "running" : "paused" }}
          >
            {coverFailed ? (
              <div className="h-full w-full bg-linear-to-br from-amber-deep to-ink-soft" />
            ) : (
              <img
                src={track.cover}
                alt=""
                className="h-full w-full object-cover"
                onError={() => setCoverFailed(true)}
              />
            )}
          </div>
          <span className="spindle" />
        </div>

        <div className="flex min-w-0 flex-1 flex-col gap-1.5">
          <div className="min-w-0">
            <p className="truncate text-[15px] font-semibold leading-tight">{track.title}</p>
            <p className="truncate text-[12.5px] leading-tight text-cream/70">{track.artist}</p>
          </div>

          <div className="relative flex h-6 items-center">
            <div className="seek-rail">
              <div className="seek-fill" style={{ width: `${progress}%` }} />
            </div>
            <input
              type="range"
              className="seek relative z-10"
              min={0}
              max={duration || 0}
              step={0.1}
              value={currentTime}
              onChange={onSeek}
              aria-label="Seek"
            />
          </div>

          <div className="flex justify-between font-mono text-[10.5px] tabular-nums text-cream-dim">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1 pr-1">
          <button
            type="button"
            onClick={goPrev}
            aria-label="Previous track"
            className="flex h-8 w-8 items-center justify-center rounded-full text-cream/80 transition-colors hover:text-cream"
          >
            <PrevIcon />
          </button>
          <button
            type="button"
            onClick={togglePlay}
            aria-label={isPlaying ? "Pause" : "Play"}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-cream text-ink transition-transform hover:scale-105"
          >
            {isPlaying ? <PauseIcon /> : <PlayIcon />}
          </button>
          <button
            type="button"
            onClick={goNext}
            aria-label="Next track"
            className="flex h-8 w-8 items-center justify-center rounded-full text-cream/80 transition-colors hover:text-cream"
          >
            <NextIcon />
          </button>
        </div>
      </div>

      {/* ---------- mobile: stacked card ---------- */}
      <div className="glass flex w-full flex-col items-center gap-4 rounded-[28px] px-6 py-6 md:hidden">
        <div className="relative h-24 w-24 shrink-0 overflow-hidden rounded-full ring-1 ring-white/10">
          <div
            className="h-full w-full animate-spin-slow"
            style={{ animationPlayState: isPlaying ? "running" : "paused" }}
          >
            {coverFailed ? (
              <div className="h-full w-full bg-linear-to-br from-amber-deep to-ink-soft" />
            ) : (
              <img
                src={track.cover}
                alt=""
                className="h-full w-full object-cover"
                onError={() => setCoverFailed(true)}
              />
            )}
          </div>
          <span className="spindle" />
        </div>

        <div className="w-full min-w-0 text-center">
          <p className="truncate text-[16px] font-semibold leading-tight">{track.title}</p>
          <p className="truncate text-[13px] leading-tight text-cream/70">{track.artist}</p>
        </div>

        <div className="w-full">
          <div className="relative flex h-6 items-center">
            <div className="seek-rail">
              <div className="seek-fill" style={{ width: `${progress}%` }} />
            </div>
            <input
              type="range"
              className="seek relative z-10"
              min={0}
              max={duration || 0}
              step={0.1}
              value={currentTime}
              onChange={onSeek}
              aria-label="Seek"
            />
          </div>
          <div className="flex justify-between font-mono text-[10.5px] tabular-nums text-cream-dim">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        <div className="flex items-center gap-5">
          <button
            type="button"
            onClick={goPrev}
            aria-label="Previous track"
            className="flex h-9 w-9 items-center justify-center rounded-full text-cream/80 transition-colors hover:text-cream"
          >
            <PrevIcon />
          </button>
          <button
            type="button"
            onClick={togglePlay}
            aria-label={isPlaying ? "Pause" : "Play"}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-cream text-ink transition-transform active:scale-95"
          >
            {isPlaying ? <PauseIcon /> : <PlayIcon />}
          </button>
          <button
            type="button"
            onClick={goNext}
            aria-label="Next track"
            className="flex h-9 w-9 items-center justify-center rounded-full text-cream/80 transition-colors hover:text-cream"
          >
            <NextIcon />
          </button>
        </div>
      </div>
    </div>
  );
}
