"use client";

import { useEffect, useState } from "react";

const START = 1204;

export default function ListenerCount() {
  const [count, setCount] = useState(START);

  useEffect(() => {
    const id = setInterval(() => {
      setCount((prev) => {
        const drift = Math.round((Math.random() - 0.48) * 9);
        const next = prev + drift;
        return next < 40 ? 40 : next;
      });
    }, 3200);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="flex items-center gap-1.5 font-mono text-[11px] tracking-wide text-cream/80">
      <span className="relative flex h-1.5 w-1.5">
        <span className="absolute inline-flex h-full w-full animate-pulse-soft rounded-full bg-amber" />
      </span>
      <span className="tabular-nums">{count.toLocaleString("en-US")}</span>
      <span className="hidden text-cream/50 sm:inline">listening</span>
    </div>
  );
}
