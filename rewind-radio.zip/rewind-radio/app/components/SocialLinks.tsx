import type { ReactNode } from "react";

type Social = {
  label: string;
  href: string;
  icon: ReactNode;
};

const socials: Social[] = [
  {
    label: "Instagram",
    href: "https://instagram.com",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
        <rect x="3" y="3" width="18" height="18" rx="5" />
        <circle cx="12" cy="12" r="4" />
        <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
      </svg>
    ),
  },
  {
    label: "X",
    href: "https://x.com",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor">
        <path d="M3 3l7.5 9.6L3.3 21h2.4l6-6.9 4.6 6.9H21l-7.8-10L20.4 3H18l-5.6 6.4L8 3H3z" />
      </svg>
    ),
  },
  {
    label: "YouTube",
    href: "https://youtube.com",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
        <rect x="2.5" y="5.5" width="19" height="13" rx="3.5" />
        <path d="M10.5 9.3l5 2.7-5 2.7z" fill="currentColor" stroke="none" />
      </svg>
    ),
  },
];

export default function SocialLinks() {
  return (
    <div className="flex items-center gap-3.5">
      {socials.map((s) => (
        <a
          key={s.label}
          href={s.href}
          target="_blank"
          rel="noreferrer noopener"
          aria-label={s.label}
          className="h-4 w-4 text-cream/70 transition-colors hover:text-cream"
        >
          {s.icon}
        </a>
      ))}
    </div>
  );
}
