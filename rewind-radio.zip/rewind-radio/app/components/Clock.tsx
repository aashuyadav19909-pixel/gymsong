"use client";

import { useEffect, useState } from "react";

function format(date: Date) {
  return date
    .toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
    .toLowerCase();
}

export default function Clock() {
  const [label, setLabel] = useState<string | null>(null);

  useEffect(() => {
    setLabel(format(new Date()));
    const id = setInterval(() => setLabel(format(new Date())), 1000 * 15);
    return () => clearInterval(id);
  }, []);

  return (
    <span className="font-mono text-[11px] tracking-wide text-cream/80 tabular-nums">
      {label ?? "--:--"}
    </span>
  );
}
