import Clock from "@/app/components/Clock";
import ListenerCount from "@/app/components/ListenerCount";
import SocialLinks from "@/app/components/SocialLinks";
import Player from "@/app/components/Player";

export default function Home() {
  return (
    <main className="relative flex min-h-dvh flex-col items-center justify-between overflow-hidden">
      <div className="hero-bg -z-20" aria-hidden="true">
        <div className="absolute inset-0 bg-linear-to-b from-black/35 via-black/20 to-black/60" />
      </div>

      <div className="grain-overlay -z-10" aria-hidden="true" />

      <div className="safe-inset flex w-full items-center justify-between px-[var(--edge)] pt-[var(--edge)]">
        <Clock />
        <ListenerCount />
        <SocialLinks />
      </div>

      <Player />
    </main>
  );
}
