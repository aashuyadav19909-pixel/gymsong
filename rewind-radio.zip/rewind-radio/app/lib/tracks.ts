export type Track = {
  id: string;
  title: string;
  artist: string;
  year: string;
  src: string;
  cover: string;
};

// Drop matching mp3s in /public/audio and cover art in /public/img/covers.
// Missing files fail gracefully — the vinyl falls back to a plain amber
// disc and the transport simply won't advance past a track with no source.
export const tracks: Track[] = [
  {
    id: "parking-lot-static",
    title: "Parking Lot Static",
    artist: "The Ceiling Fans",
    year: "1998",
    src: "/audio/parking-lot-static.mp3",
    cover: "/img/covers/parking-lot-static.jpg",
  },
  {
    id: "second-grade-summer",
    title: "Second Grade Summer",
    artist: "Nadia Cole",
    year: "2003",
    src: "/audio/second-grade-summer.mp3",
    cover: "/img/covers/second-grade-summer.jpg",
  },
  {
    id: "vhs-blue",
    title: "VHS Blue",
    artist: "Late Bloom",
    year: "1996",
    src: "/audio/vhs-blue.mp3",
    cover: "/img/covers/vhs-blue.jpg",
  },
  {
    id: "porch-light-radio",
    title: "Porch Light Radio",
    artist: "Marion & The Static",
    year: "2001",
    src: "/audio/porch-light-radio.mp3",
    cover: "/img/covers/porch-light-radio.jpg",
  },
];
