# rewind — a nostalgia radio, single page

## Run it

```
npm install
npm run dev
```

## Assets you provide

Drop these in before the hero looks right:

- `public/img/scene-wide.png` — landscape, shown by default
- `public/img/scene-tall.png` — portrait, swapped in under
  `@media (orientation: portrait)`; compose it separately, don't just
  crop the wide one

The player works with no assets at all — a missing cover falls back to a
plain amber disc, and a track with no matching mp3 just won't advance the
seek bar when pressed play.

## Wiring up real tracks

Edit `app/lib/tracks.ts`. Each entry needs:

- `src` — path under `public/audio/`
- `cover` — path under `public/img/covers/`

Both the desktop pill and the mobile card read from the same array and the
same `<audio>` element in `app/components/Player.tsx`, so you only ever
edit one file to change the playlist.

## Structure

```
app/
  layout.tsx        fonts, viewport (viewportFit: cover), analytics
  page.tsx           background + grain + top row + <Player />
  globals.css        @theme tokens, hero-bg, grain, glass, seek bar
  lib/tracks.ts       playlist data
  components/
    Player.tsx        single <audio>, desktop pill + mobile card
    Clock.tsx
    ListenerCount.tsx  simulated live count
    SocialLinks.tsx
```

## Notes

- Corner spacing everywhere uses `max(1rem, env(safe-area-inset-top))`
  via the `.safe-inset` class, so it clears notches on iOS in both
  orientations.
- Gradients use Tailwind v4's `bg-linear-*` naming (the old
  `bg-gradient-*` utilities were renamed in v4).
- `prefers-reduced-motion` stops the vinyl spin and the listener-count
  pulse.
